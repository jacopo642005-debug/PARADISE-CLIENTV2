# PARADISE CLIENT v1.2

Questa versione ricrea l'impostazione grafica del mockup Paradise Smoke:
- nero profondo
- card sottili e arrotondate
- neon verde/ciano
- dettagli rosa
- logo Paradise Smoke
- look da app premium / club
- navigazione Home / Punti / News / Social / Altro
- tessera con QR
- buoni con QR
- news
- social
- Google Reviews
- area Admin
- scanner fotocamera di base
- installabile come PWA

## USO IMMEDIATO
La cartella deve essere pubblicata su un indirizzo HTTPS. Puoi usare un hosting statico gratuito.
Poi aprila da iPhone/Android e scegli "Aggiungi alla schermata Home"/"Installa app".

## LIMITAZIONE V1.2
I dati sono salvati localmente nel browser/device. Quindi questa versione è utilizzabile subito come demo operativa su un singolo dispositivo, ma non sincronizza automaticamente telefono cliente e telefono del negozio.

## V2
Per il sistema reale multi-dispositivo occorre collegare un database/authentication backend e rendere il pannello Admin protetto.
